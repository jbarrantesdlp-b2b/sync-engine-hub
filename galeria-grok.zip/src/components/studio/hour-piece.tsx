import { memo, useEffect, useRef, useState, type PointerEvent, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay } from "date-fns";
import { es } from "date-fns/locale";
import { ArrowDown, ArrowUp, Pause, Play, SkipBack, SkipForward } from "lucide-react";
import { useNow } from "@/hooks/use-now";
import { useWeather } from "@/hooks/use-weather";
import { LockFace, LockScreen } from "@/components/studio/lock-screen";

export function HourScreen({
  signedIn,
  onStudio,
}: {
  signedIn: boolean;
  onStudio: () => void;
}) {
  const [lock, setLock] = useState(false);
  const [theme, setTheme] = useState("cian");
  const themes = [
    ["cian", "Cian"],
    ["ambar", "Ámbar"],
    ["claro", "Claro"],
    ["aire", "Aire"],
    ["violeta", "Violeta"],
  ] as const;
  return (
    <div className="studio hour-screen" data-theme={theme}>
      {lock ? (
        <LockScreen onClose={() => setLock(false)} />
      ) : (
    <>
      <header className="studio-bar">
        <div className="studio-id">
          <img src="/brand-kit/mark-48.png" alt="" />
          <div>
            <p className="studio-mark">SYNC ENGINE</p>
            <p className="studio-by">BARRANTES CO.</p>
          </div>
        </div>
        <div className="studio-bar-end">
          <button type="button" className="studio-go studio-go-inline" onClick={() => setLock(true)}>
            Bloqueo
          </button>
          {signedIn ? (
          <button type="button" className="studio-go studio-go-inline" onClick={onStudio}>
            Estudio
          </button>
        ) : (
          <Link to="/login" className="studio-go studio-go-inline">
            Crear cuenta
          </Link>
        )}
        </div>
      </header>
      <div className="theme-bar" role="tablist" aria-label="Temas">
        {themes.map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={theme === id} className={theme === id ? "is-on" : ""} onClick={() => setTheme(id)}>
            <i data-swatch={id} />
            {label}
          </button>
        ))}
      </div>
      <div className="hour-stage">
        <div className="lock-phone" onClick={() => setLock(true)}>
          <LockFace />
        </div>
        <TypeBoard />
        <ClimateClock />
        <StackClock />
        <HourPiece />
        <SvgExamples />
        <SvgFilters />
        <GlassLab />
        <OrbitClock />
        <TelemetryClock />
        <SplitClock />
        <RiseClock />
        <AgendaWidget />
        <CalendarWidget />
        <PanelWidget />
        <SkyWidget />
        <DaylightWidget />
        <ZoneWidget />
        <CompassWidget />
        <AudioWidget />
        <Dashboard />
      </div>
    </>
      )}
    </div>
  );
}

function TypeBoard() {
  const now = useNow(1000);
  const rows = [
    ["Actual", "Inter, sans-serif", "Neutra. No se distingue."],
    ["Técnica", '"Space Grotesk", sans-serif', "Para la hora."],
    ["Marca", "Syne, sans-serif", "Para el nombre."],
  ] as const;
  return (
    <section className="type-board" aria-label="Tipografía de marca">
      {rows.map(([name, font, note]) => (
        <article key={name} style={{ fontFamily: font }}>
          <p className="type-kicker">{name}</p>
          <p className="type-word">SYNC ENGINE</p>
          <p className="type-by">BARRANTES CO.</p>
          <p className="type-time" suppressHydrationWarning>
            {format(now, "HH:mm")}
          </p>
          <p className="type-note">{note}</p>
        </article>
      ))}
    </section>
  );
}

function Shell({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <article className={`hour ${className}`}>{children}</article>;
}

function ago(at: number) {
  const mins = Math.max(0, Math.round((Date.now() - at) / 60000));
  if (mins < 1) return "ahora";
  if (mins < 60) return `hace ${mins} min`;
  const h = Math.floor(mins / 60);
  return `hace ${h} h ${mins % 60} min`;
}

function SkyIcon({ code }: { code?: number }) {
  const cloud = code == null || code > 1;
  return (
    <svg className="sky-ico" viewBox="0 0 48 32" aria-hidden="true">
      {cloud ? (
        <path
          fill="currentColor"
          d="M16 26h18a8 8 0 0 0 1.2-15.9 10 10 0 0 0-19.2 2.2A6.5 6.5 0 0 0 16 26z"
        />
      ) : (
        <circle cx="24" cy="16" r="8" fill="currentColor" />
      )}
    </svg>
  );
}

function ClimateClock() {
  const now = useNow(30_000);
  const weather = useWeather();
  const hi = weather?.high == null ? "—" : `${weather.high}°`;
  const lo = weather?.low == null ? "—" : `${weather.low}°`;
  return (
    <Shell className="plate">
      <span className="plate-arc" aria-hidden="true" />
      <div className="plate-main">
        <div className="plate-meta">
          <div className="plate-top">
            <p>{weather?.city ?? "—"}</p>
            <SkyIcon code={weather?.code} />
          </div>
          <p className="plate-temp">{weather ? `${weather.temp}°` : "—"}</p>
          <p className="plate-range">
            H:{hi} L:{lo}
          </p>
          <p className="plate-ago">{weather ? `Actualizado ${ago(weather.at)}` : "Sin sincronizar"}</p>
        </div>
        <div className="plate-clock">
          <p className="plate-hour" suppressHydrationWarning>
            {format(now, "HH:mm")}
          </p>
          <p className="plate-day" suppressHydrationWarning>
            {format(now, "dd / MM / yyyy")}
          </p>
        </div>
      </div>
    </Shell>
  );
}

function StackClock() {
  const now = useNow(30_000);
  const weather = useWeather();
  const [battery, setBattery] = useState<number | null>(null);
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number }> };
    if (!nav.getBattery) return;
    let alive = true;
    nav.getBattery().then((bat) => {
      if (alive) setBattery(Math.round(bat.level * 100));
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  const raw = format(now, "EEEE, d 'de' MMMM", { locale: es });
  const date = raw.charAt(0).toUpperCase() + raw.slice(1);
  return (
    <Shell className="stack">
      <div className="stack-time">
        <p className="stack-num" suppressHydrationWarning>
          {format(now, "HH")}
        </p>
        <p className="stack-num" suppressHydrationWarning>
          {format(now, "mm")}
        </p>
        <p className="stack-date" suppressHydrationWarning>
          {date}
        </p>
      </div>
      <div className="stack-side">
        <div className="stack-pill">
          <SkyIcon code={weather?.code} />
          <span>{weather ? `${weather.temp}°` : "—"}</span>
          <small>{weather?.city ?? "—"}</small>
        </div>
        <div className="stack-rings">
          <Meter value={null} caption="Pasos" />
          <Meter value={battery} caption={battery == null ? "—" : `${battery}%`} />
        </div>
      </div>
    </Shell>
  );
}

function Meter({ value, caption }: { value: number | null; caption: string }) {
  const pct = value == null ? 0 : Math.max(0, Math.min(100, value));
  return (
    <div className="meter" style={{ ["--p" as string]: `${pct * 3.6}deg` }}>
      <span>{caption}</span>
    </div>
  );
}

export function HourPiece() {
  const now = useNow(1000);
  const [fondo, setFondo] = useState<Fondo>("negro");
  const [aire, setAire] = useState<Aire>("humo");
  const [spot, setSpot] = useState({ x: 50, y: 46, on: false });
  function place(event: PointerEvent<HTMLDivElement>, on: boolean) {
    const box = event.currentTarget.getBoundingClientRect();
    setSpot({
      x: ((event.clientX - box.left) / box.width) * 100,
      y: ((event.clientY - box.top) / box.height) * 100,
      on,
    });
  }
  const fondos = [
    ["negro", "Negro"],
    ["velo", "Velo"],
    ["grano", "Grano"],
    ["bruma", "Bruma"],
  ] as const;
  const aires = [
    ["humo", "Humo"],
    ["burbuja", "Burbujas"],
    ["polvo", "Polvo"],
    ["quieto", "Quieto"],
  ] as const;
  return (
    <div className="edge-pick">
      <Shell className={`fondo-${fondo}`}>
        <SoftField mode={aire} />
        <Flux />
        <span
          className={spot.on ? "touch-glow is-on" : "touch-glow"}
          style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
        />
        <p className="hour-time" suppressHydrationWarning>
          {format(now, "HH:mm")}
        </p>
        <p className="hour-date" suppressHydrationWarning>
          {format(now, "d")} {format(now, "EEEE", { locale: es })} {format(now, "yyyy")}
        </p>
        <div
          className="touch-catch"
          onPointerDown={(event) => place(event, true)}
          onPointerMove={(event) => {
            if (event.buttons !== 1 && event.pointerType === "mouse") return;
            place(event, true);
          }}
          onPointerUp={() => setSpot((prev) => ({ ...prev, on: false }))}
          onPointerLeave={() => setSpot((prev) => ({ ...prev, on: false }))}
        />
      </Shell>
      <div className="edge-bar" role="tablist" aria-label="Fondo">
        {fondos.map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={fondo === id} className={fondo === id ? "is-on" : ""} onClick={() => setFondo(id)}>
            {label}
          </button>
        ))}
      </div>
      <div className="edge-bar" role="tablist" aria-label="Fondo animado">
        {aires.map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={aire === id} className={aire === id ? "is-on" : ""} onClick={() => setAire(id)}>
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

type Fondo = "negro" | "velo" | "grano" | "bruma";
type Aire = "humo" | "burbuja" | "polvo" | "quieto";

function SvgExamples() {
  return (
    <div className="svg-lab" aria-label="Ejemplos de SVG animado">
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <path className="lab-dash" pathLength={100} d="M 8 62 C 70 12, 150 88, 230 36 S 300 70, 312 28" />
        </svg>
        <figcaption>Tramo</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <defs>
            <linearGradient id="lab-sheen" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#ff4fd8" stopOpacity="0" />
              <stop offset="0.45" stopColor="#fff" />
              <stop offset="1" stopColor="#67e8f9" stopOpacity="0" />
              <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="2.8s" repeatCount="indefinite" />
            </linearGradient>
          </defs>
          <path className="lab-sheen" d="M 8 48 C 80 88, 160 8, 240 64 S 300 20, 312 52" />
        </svg>
        <figcaption>Brillo</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <path id="lab-orbit" d="M 16 48 C 80 8, 140 88, 200 48 S 280 8, 304 48" fill="none" />
          <path className="lab-guide" d="M 16 48 C 80 8, 140 88, 200 48 S 280 8, 304 48" />
          {[0, 0.35, 0.7].map((begin) => (
            <circle key={begin} r={begin === 0 ? 3.2 : 1.6} fill="#fff" opacity={begin === 0 ? 1 : 0.45}>
              <animateMotion dur="3.4s" begin={`${-begin * 3.4}s`} repeatCount="indefinite">
                <mpath href="#lab-orbit" />
              </animateMotion>
            </circle>
          ))}
        </svg>
        <figcaption>Punta</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <path className="lab-a" pathLength={100} d="M 8 28 C 80 8, 140 70, 210 28 S 280 70, 312 24" />
          <path className="lab-b" pathLength={100} d="M 8 68 C 80 88, 140 26, 210 68 S 280 26, 312 72" />
        </svg>
        <figcaption>Doble</figcaption>
      </figure>
    </div>
  );
}

const labCurve = "M 8 52 C 70 12, 150 88, 230 36 S 300 70, 312 28";

function SvgFilters() {
  return (
    <div className="svg-lab" aria-label="Filtros SVG">
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <defs>
            <filter id="fx-halo" x="-20%" y="-60%" width="140%" height="220%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <path className="lab-solid" filter="url(#fx-halo)" d={labCurve} />
        </svg>
        <figcaption>Halo</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <defs>
            <filter id="fx-bloom" x="-25%" y="-70%" width="150%" height="240%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0.2  0 0.2 0 0 0.05  0 0 1 0 0.15  0 0 0 1.4 0" result="glow" />
              <feMerge>
                <feMergeNode in="glow" />
                <feMergeNode in="glow" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <path className="lab-solid" filter="url(#fx-bloom)" d={labCurve} />
        </svg>
        <figcaption>Bloom</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <defs>
            <filter id="fx-wave" x="-10%" y="-40%" width="120%" height="180%">
              <feTurbulence type="fractalNoise" baseFrequency="0.012 0.04" numOctaves="1" seed="3" result="noise">
                <animate attributeName="baseFrequency" values="0.01 0.03;0.02 0.06;0.01 0.03" dur="6s" repeatCount="indefinite" />
              </feTurbulence>
              <feDisplacementMap in="SourceGraphic" in2="noise" scale="7" />
            </filter>
          </defs>
          <path className="lab-solid" filter="url(#fx-wave)" d={labCurve} />
        </svg>
        <figcaption>Onda</figcaption>
      </figure>
      <figure>
        <svg viewBox="0 0 320 96" aria-hidden="true">
          <defs>
            <filter id="fx-glass" x="-20%" y="-50%" width="140%" height="200%">
              <feGaussianBlur stdDeviation="1.2" result="soft" />
              <feSpecularLighting in="soft" surfaceScale="4" specularConstant="1.1" specularExponent="24" lightingColor="#d7f8ff" result="spec">
                <fePointLight x="40" y="10" z="50">
                  <animate attributeName="x" values="20;300;20" dur="4.5s" repeatCount="indefinite" />
                </fePointLight>
              </feSpecularLighting>
              <feComposite in="spec" in2="SourceAlpha" operator="in" result="lit" />
              <feMerge>
                <feMergeNode in="SourceGraphic" />
                <feMergeNode in="lit" />
              </feMerge>
            </filter>
          </defs>
          <path className="lab-solid" filter="url(#fx-glass)" d={labCurve} />
        </svg>
        <figcaption>Cristal</figcaption>
      </figure>
    </div>
  );
}

function GlassLab() {
  const panes = [
    ["blur(10px)", "Desenfoque"],
    ["saturate(1.8)", "Saturación"],
    ["brightness(1.35)", "Brillo"],
    ["contrast(1.3)", "Contraste"],
    ["hue-rotate(40deg)", "Tono"],
    ["blur(8px) saturate(1.4)", "Combinado"],
  ] as const;
  return (
    <div className="glass-lab" aria-label="Propiedades de backdrop-filter">
      {panes.map(([filter, label]) => (
        <figure key={label}>
          <i style={{ backdropFilter: filter }} />
          <figcaption>{label}</figcaption>
        </figure>
      ))}
    </div>
  );
}

function Flux() {
  const ribbons = [
    ["M -30 118 C 90 28, 210 196, 340 86 S 500 24, 580 132", "url(#flux-mag)", 5.2],
    ["M -40 150 C 70 196, 180 70, 320 150 S 490 40, 600 96", "url(#flux-cyan)", 3.4],
    ["M -20 64 C 120 8, 230 120, 380 48 S 540 96, 620 36", "url(#flux-violet)", 2.6],
    ["M -10 104 C 140 168, 260 40, 410 128 S 560 70, 640 150", "url(#flux-gold)", 4],
  ] as const;
  return (
    <svg className="flux" viewBox="0 0 520 220" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="flux-mag" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ff4fd8" stopOpacity="0" />
          <stop offset="0.45" stopColor="#fff" />
          <stop offset="1" stopColor="#ff4fd8" stopOpacity="0" />
          <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="3.2s" repeatCount="indefinite" />
        </linearGradient>
        <linearGradient id="flux-cyan" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#67e8f9" stopOpacity="0" />
          <stop offset="0.45" stopColor="#fff" />
          <stop offset="1" stopColor="#22d3ee" stopOpacity="0" />
          <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="4.4s" begin="-1.6s" repeatCount="indefinite" />
        </linearGradient>
        <linearGradient id="flux-violet" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#c4b5fd" stopOpacity="0" />
          <stop offset="0.5" stopColor="#fff" />
          <stop offset="1" stopColor="#a78bfa" stopOpacity="0" />
          <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="5.1s" begin="-2.4s" repeatCount="indefinite" />
        </linearGradient>
        <linearGradient id="flux-gold" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#fbbf24" stopOpacity="0" />
          <stop offset="0.42" stopColor="#fff" />
          <stop offset="1" stopColor="#67e8f9" stopOpacity="0" />
          <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="3.8s" begin="-0.8s" repeatCount="indefinite" />
        </linearGradient>
        <filter id="flux-light" x="-30%" y="-90%" width="160%" height="280%">
          <feGaussianBlur stdDeviation="3.2" result="blur" />
          <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0.2  0 0.2 0 0 0.05  0 0 1 0 0.15  0 0 0 1.4 0" result="bloom" />
          <feMerge>
            <feMergeNode in="bloom" />
            <feMergeNode in="bloom" />
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      {ribbons.map(([d, stroke, width]) => (
        <path key={d} className="flux-line" d={d} stroke={stroke} strokeWidth={width} filter="url(#flux-light)" />
      ))}
    </svg>
  );
}

function SoftField({ mode }: { mode: Aire }) {
  if (mode === "quieto") return null;
  const count = mode === "humo" ? 5 : mode === "burbuja" ? 8 : 14;
  return (
    <div className={`soft-field air-${mode}`} aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <i
          key={i}
          style={{
            left: mode === "polvo" ? undefined : `${6 + ((i * 17) % 84)}%`,
            top: mode === "polvo" ? `${8 + ((i * 13) % 78)}%` : undefined,
            animationDelay: `${-i * 1.4}s`,
            animationDuration: `${9 + (i % 5) * 1.8}s`,
          }}
        />
      ))}
    </div>
  );
}

function SplitClock() {
  const now = useNow(1000);
  return (
    <article className="hour hour-split">
      <div className="split-face">
        <svg className="lock-dial split-ring" viewBox="0 0 200 200" aria-hidden="true">
          <circle className="lock-ring" cx="100" cy="100" r="70" />
          {Array.from({ length: 12 }, (_, index) => {
            const angle = (index / 12) * Math.PI * 2 - Math.PI / 2;
            return (
              <line
                key={index}
                className="is-major"
                x1={100 + Math.cos(angle) * 76}
                y1={100 + Math.sin(angle) * 76}
                x2={100 + Math.cos(angle) * 88}
                y2={100 + Math.sin(angle) * 88}
              />
            );
          })}
          <g className="lock-spin">
            <circle className="lock-arc" cx="100" cy="100" r="93" />
          </g>
        </svg>
        <div className="split-core">
          <p className="split-nums" suppressHydrationWarning>
            {format(now, "HH:mm")}
          </p>
          <p className="split-date" suppressHydrationWarning>
            {format(now, "EEE d", { locale: es })}
          </p>
        </div>
      </div>
    </article>
  );
}

const OrbitBlob = memo(function OrbitBlob() {
  return (
    <svg className="orbit-blob" viewBox="0 0 200 200" aria-hidden="true">
      <defs>
        <filter id="orbit-blob" x="-20%" y="-20%" width="140%" height="140%">
          <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="1" seed="8" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="14" />
        </filter>
      </defs>
      <circle className="orbit-shadow" cx="103" cy="106" r="66" filter="url(#orbit-blob)" />
      <circle className="orbit-ring" cx="100" cy="100" r="66" filter="url(#orbit-blob)" />
    </svg>
  );
});

function OrbitClock() {
  const now = useNow(60_000);
  const passed = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const progress = passed / 86400;
  const day = 2 * Math.PI * 66;
  const [sweep, setSweep] = useState(0);
  const [intro, setIntro] = useState(true);
  const progressRef = useRef(progress);
  progressRef.current = progress;
  useEffect(() => {
    const frame = requestAnimationFrame(() => setSweep(progressRef.current));
    const done = window.setTimeout(() => setIntro(false), 2400);
    return () => {
      cancelAnimationFrame(frame);
      window.clearTimeout(done);
    };
  }, []);
  const face = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = face.current;
    const svg = node?.querySelector(".orbit-motion");
    if (!node || !(svg instanceof SVGSVGElement)) return;
    const spin = () =>
      svg.getAnimations({ subtree: true }).find(
        (item): item is CSSAnimation =>
          item instanceof CSSAnimation && item.animationName === "orbit-spin",
      );
    const watch = new IntersectionObserver(([entry]) => {
      const anim = spin();
      if (!anim || anim.playState === "idle") return;
      if (entry.isIntersecting) {
        if (anim.playState === "paused") anim.play();
      } else if (anim.playState === "running") {
        anim.pause();
      }
    });
    watch.observe(node);
    return () => watch.disconnect();
  }, []);
  useEffect(() => {
    if (!intro) setSweep(progress);
  }, [progress, intro]);
  return (
    <article className="hour hour-orbit">
      <div className="orbit-face" ref={face}>
        <OrbitBlob />
        <svg className="orbit-motion" viewBox="0 0 200 200" aria-hidden="true">
          <circle
            className={intro ? "orbit-day is-intro" : "orbit-day"}
            cx="100"
            cy="100"
            r="66"
            transform="rotate(-90 100 100)"
            strokeDasharray={`${sweep * day} ${day}`}
          />
          <g className="orbit-flow">
            <circle className="orbit-arc" cx="100" cy="100" r="66" />
            <circle className="orbit-knob" cx="149" cy="144" r="4.2" />
          </g>
        </svg>
        <div className="orbit-core">
          <p className="orbit-time" suppressHydrationWarning>
            {format(now, "HH:mm")}
          </p>
          <p className="orbit-date" suppressHydrationWarning>
            {format(now, "EEE, d MMM", { locale: es })}
          </p>
        </div>
      </div>
      <div className="orbit-stats">
        <div>
          <p>
            <span aria-hidden="true">👟</span> Pasos
          </p>
          <b>0</b>
        </div>
        <div>
          <p>
            <span aria-hidden="true">☀️</span> Clima
          </p>
          <b>20°</b>
        </div>
      </div>
    </article>
  );
}

function TelemetryClock() {
  const now = useNow(1000);
  return (
    <article className="hour hour-tele">
      <p className="tele-time" suppressHydrationWarning>
        {format(now, "HH:mm")}
      </p>
      <div className="tele-row">
        <p>
          <b>—</b>
          <span>Temperatura</span>
        </p>
        <p>
          <b>—</b>
          <span>Pasos</span>
        </p>
      </div>
    </article>
  );
}

function RiseClock() {
  const now = useNow(1000);
  return (
    <article className="hour hour-rise">
      <div className="rise">
        <p className="rise-nums" suppressHydrationWarning>
          <span>{format(now, "HH")}</span>
          <span>{format(now, "mm")}</span>
        </p>
        <div className="rise-date">
          <p suppressHydrationWarning>{format(now, "EEEE", { locale: es })}</p>
          <i />
          <p suppressHydrationWarning>{format(now, "d MMM", { locale: es })}</p>
        </div>
      </div>
      <p className="rise-meta">Temperatura —</p>
    </article>
  );
}

const WEEK = ["L", "M", "X", "J", "V", "S", "D"];

function CalendarWidget() {
  const now = useNow(60_000);
  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(now), { weekStartsOn: 1 }),
    end: endOfWeek(endOfMonth(now), { weekStartsOn: 1 }),
  });

  return (
    <article className="hour hour-cal">
      <div className="cal-head">
        <p suppressHydrationWarning>{format(now, "EEEE", { locale: es })}</p>
        <p suppressHydrationWarning>{format(now, "MMMM yyyy", { locale: es })}</p>
      </div>
      <div className="cal-body">
        <div className="cal-grid">
          {WEEK.map((d) => (
            <span key={d} className="cal-dow">
              {d}
            </span>
          ))}
          {days.map((day) => {
            const inMonth = isSameMonth(day, now);
            const today = isSameDay(day, now);
            return (
              <span key={day.toISOString()} className={today ? "is-today" : inMonth ? "" : "is-out"}>
                {format(day, "d")}
              </span>
            );
          })}
        </div>
        <div className="cal-events">
          <p>Agenda</p>
          <b>Sin actividad</b>
        </div>
      </div>
    </article>
  );
}

function AgendaWidget() {
  const now = useNow(1000);
  return (
    <article className="hour hour-agenda">
      <p className="hour-time" suppressHydrationWarning>
        {format(now, "d")}
      </p>
      <p className="hour-date" suppressHydrationWarning>
        {format(now, "EEEE", { locale: es })} {format(now, "yyyy")}
      </p>
      <p className="hour-note">Sin actividad</p>
    </article>
  );
}

type PhoneBattery = {
  level: number;
  charging: boolean;
  addEventListener: (type: string, cb: () => void) => void;
  removeEventListener: (type: string, cb: () => void) => void;
};

export function usePhoneBattery() {
  const [battery, setBattery] = useState<{ level: number; charging: boolean } | null>(null);
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<PhoneBattery> };
    if (!nav.getBattery) return;
    let item: PhoneBattery | null = null;
    let alive = true;
    const read = () => {
      if (!item || !alive) return;
      setBattery({ level: Math.round(item.level * 100), charging: item.charging });
    };
    nav.getBattery().then((battery) => {
      item = battery;
      read();
      battery.addEventListener("levelchange", read);
      battery.addEventListener("chargingchange", read);
    });
    return () => {
      alive = false;
      item?.removeEventListener("levelchange", read);
      item?.removeEventListener("chargingchange", read);
    };
  }, []);
  return battery;
}

function ZoneWidget() {
  const now = useNow(1000);
  const zones = [
    ["Lima", "America/Lima"],
    ["Nueva York", "America/New_York"],
  ] as const;
  return (
    <article className="hour hour-zones">
      {zones.map(([city, zone]) => (
        <div key={zone}>
          <span>{city}</span>
          <b suppressHydrationWarning>
            {new Intl.DateTimeFormat("es-PE", {
              timeZone: zone,
              hour: "2-digit",
              minute: "2-digit",
              hour12: false,
            }).format(now)}
          </b>
        </div>
      ))}
    </article>
  );
}

function CompassWidget() {
  const [heading, setHeading] = useState<number | null>(null);
  useEffect(() => {
    const onOrient = (event: DeviceOrientationEvent) => {
      if (typeof event.alpha !== "number") return;
      setHeading(Math.round(event.alpha));
    };
    window.addEventListener("deviceorientation", onOrient);
    return () => window.removeEventListener("deviceorientation", onOrient);
  }, []);
  return (
    <article className="hour hour-compass">
      <svg viewBox="0 0 100 100" aria-hidden="true" style={{ transform: `rotate(${heading ?? 0}deg)` }}>
        <circle cx="50" cy="50" r="46" />
        <polygon points="50,12 56,50 50,44 44,50" />
        <polygon points="50,88 56,50 50,56 44,50" />
      </svg>
      <p>{heading == null ? "—" : `${heading}°`}</p>
    </article>
  );
}

function DaylightWidget() {
  return (
    <article className="hour hour-day">
      <div className="day-row">
        <div className="day-side">
          <b>—</b>
          <span>Hora dorada</span>
          <b>—</b>
        </div>
        <div className="day-mid">
          <svg viewBox="0 0 120 64" aria-hidden="true">
            <path d="M8 60 A52 52 0 0 1 112 60" />
            <circle cx="60" cy="10" r="5" />
          </svg>
          <p>Luz del día</p>
          <b>—</b>
        </div>
        <div className="day-side">
          <b>—</b>
          <span>Hora dorada</span>
          <b>—</b>
        </div>
      </div>
      <div className="day-ends">
        <p>
          <b>—</b> Salida sol
        </p>
        <p>
          <b>—</b> Puesta sol
        </p>
      </div>
    </article>
  );
}

function SkyWidget() {
  return (
    <article className="hour hour-sky">
      <p className="sky-temp">—</p>
      <p className="sky-state">Sin dato</p>
      <div className="sky-range">
        <span>
          <ArrowDown />—
        </span>
        <span>
          <ArrowUp />—
        </span>
      </div>
    </article>
  );
}

function PanelWidget() {
  const now = useNow(1000);
  const battery = usePhoneBattery();
  const week = eachDayOfInterval({
    start: startOfWeek(now, { weekStartsOn: 1 }),
    end: endOfWeek(now, { weekStartsOn: 1 }),
  });
  const hourAngle = ((now.getHours() % 12) + now.getMinutes() / 60) * 30;
  const minuteAngle = (now.getMinutes() + now.getSeconds() / 60) * 6;

  return (
    <article className="hour hour-panel">
      <div className="panel-top">
        <p suppressHydrationWarning>{format(now, "MMMM", { locale: es })}</p>
        <span suppressHydrationWarning>{format(now, "EEEE d", { locale: es })}</span>
      </div>
      <div className="panel-week">
        {week.map((day, index) => (
          <span key={day.toISOString()} className={isSameDay(day, now) ? "is-today" : ""}>
            <i>{WEEK[index]}</i>
            {format(day, "d")}
          </span>
        ))}
      </div>
      <div className="panel-foot">
        <div>
          <p>Temperatura <b>—</b></p>
          <p>
            Carga{" "}
            <b>
              {battery ? `${battery.level}%` : "—"}
              {battery ? ` · ${battery.charging ? "cargando" : "sin cargar"}` : ""}
            </b>
          </p>
        </div>
        <svg className="panel-dial" viewBox="0 0 100 100" aria-hidden="true">
          <circle cx="50" cy="50" r="46" />
          <circle className="panel-arc" cx="50" cy="50" r="40" />
          <line x1="50" y1="50" x2="50" y2="30" transform={`rotate(${hourAngle} 50 50)`} />
          <line className="is-min" x1="50" y1="52" x2="50" y2="18" transform={`rotate(${minuteAngle} 50 50)`} />
        </svg>
      </div>
    </article>
  );
}

function AudioWidget() {
  const [player, setPlayer] = useState({
    configured: false,
    connected: false,
    playing: false,
    title: null as string | null,
    artist: null as string | null,
    art: null as string | null,
    progressMs: 0,
    durationMs: 0,
  });

  useEffect(() => {
    let alive = true;
    const pull = () => {
      fetch("/api/spotify/player")
        .then((res) => res.json())
        .then((data) => {
          if (alive) setPlayer(data);
        })
        .catch(() => undefined);
    };
    pull();
    const timer = window.setInterval(pull, 8000);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, []);

  async function command(action: "previous" | "play" | "pause" | "next") {
    if (!player.connected) return;
    await fetch("/api/spotify/player", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    const next = await fetch("/api/spotify/player").then((res) => res.json());
    setPlayer(next);
  }

  const ratio = player.durationMs > 0 ? Math.min(1, player.progressMs / player.durationMs) : 0;
  const title = player.title
    ? player.title
    : player.connected
      ? "Nada en reproducción"
      : player.configured
        ? "Conectar Spotify"
        : "Sin sesión";
  const artist = player.artist ?? (player.configured ? "—" : "Falta la clave de Spotify");

  return (
    <article className="hour hour-spotify">
      <div className="spot-top">
        <div
          className="spot-art"
          role="img"
          aria-label="Carátula del artista"
          style={player.art ? { backgroundImage: `url(${player.art})` } : undefined}
        />
        <div className="spot-meta">
          <p className="spot-title">{title}</p>
          <p className="spot-artist">{artist}</p>
        </div>
      </div>
      <div className="spot-progress" aria-hidden="true">
        <i style={{ width: `${ratio * 100}%` }} />
      </div>
      <div className="spot-controls">
        <button type="button" aria-label="Anterior" disabled={!player.connected} onClick={() => command("previous")}>
          <SkipBack />
        </button>
        {player.configured && !player.connected ? (
          <a className="is-main" href="/api/spotify/login" aria-label="Conectar Spotify">
            <Play />
          </a>
        ) : (
          <button
            type="button"
            className="is-main"
            aria-label={player.playing ? "Pausa" : "Reproducir"}
            disabled={!player.connected}
            onClick={() => command(player.playing ? "pause" : "play")}
          >
            {player.playing ? <Pause /> : <Play />}
          </button>
        )}
        <button type="button" aria-label="Siguiente" disabled={!player.connected} onClick={() => command("next")}>
          <SkipForward />
        </button>
      </div>
    </article>
  );
}

function Dashboard() {
  const [volume, setVolume] = useState(62);
  const [light, setLight] = useState(40);

  return (
    <Shell>
      <div className="dash-row">
        <span>Volumen</span>
        <input
          className="hour-range"
          type="range"
          min={0}
          max={100}
          value={volume}
          aria-label="Volumen"
          style={{ background: `linear-gradient(90deg, #126980 ${volume}%, #141a1e ${volume}%)` }}
          onChange={(e) => setVolume(Number(e.target.value))}
        />
        <b>{volume}</b>
      </div>
      <div className="dash-row">
        <span>Brillo</span>
        <input
          className="hour-range"
          type="range"
          min={0}
          max={100}
          value={light}
          aria-label="Brillo"
          style={{ background: `linear-gradient(90deg, #126980 ${light}%, #141a1e ${light}%)` }}
          onChange={(e) => setLight(Number(e.target.value))}
        />
        <b>{light}</b>
      </div>
    </Shell>
  );
}
